import pygame

class Missile:
    def __init__(self, screen, boss, enemy):
        self.screen = screen

        self.boss = boss
        self.enemy = enemy
        
        self.missile_img = pygame.image.load('resource/bullet.png')
        self.missile_img2 = pygame.image.load('resource/bullet2.png')
        
        self.missile_pos = []
        self.missile_posU = []

        self.isShot = False
        
    def draw(self):
        if len(self.missile_pos) != 0:
            for self.x, self.y in self.missile_pos:
                self.screen.blit(self.missile_img, (self.x, self.y))

        if len(self.missile_posU) != 0:
            for self.x, self.y in self.missile_posU:
                self.screen.blit(self.missile_img2, (self.x, self.y))

    def update(self):

        if len(self.missile_pos) != 0:
            for self.i, self.mxy in enumerate(self.missile_pos):
                self.mxy[0] += 10
                self.missile_pos[self.i][0] = self.mxy[0]
                
                if self.missile_pos[self.i][0] > 2000:
                    del self.missile_pos[self.i]
                
                if self.boss.bsx <= self.mxy[0] < self.boss.bsx+100:
                    if self.boss.bsy <= self.mxy[1] <= self.boss.bsy+100:
                        self.isShot = True
                        del self.missile_pos[self.i]

                if self.enemy.ex <= self.mxy[0] < self.enemy.ex + 100:
                    if self.enemy.ey <= self.mxy[1] <= self.enemy.ey+100:
                        self.isShot = True
                        del self.missile_pos[self.i]

        if self.isShot:
            self.boss.hp -= 10
            self.isShot = False

            self.enemy.isDead = True
            
            if self.boss.hp <= 0:
                self.boss.isDead = True
                






        
