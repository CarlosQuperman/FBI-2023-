import pygame
import random

class Enemy :

    def __init__(self, screen):
        self.screen = screen 
        self.enemy_img = pygame.image.load("resource/enemy/play_babybear_run_0.png")
        self.ex = 1000
        self.ey = random.randrange(0, 900)

        self.isDead = False
        
    def draw(self):
        if not self.isDead:
            self.screen.blit(self.enemy_img, (self.ex, self.ey))


    def update(self):

        self.ex -= 3

        if self.ex <-100:
            self.ex = 1900
            self.ey = random.randrange(0, 900)


        if self.isDead:
            self.ex = 1920
            self.ey = random.randrange(0, 900)
            self.isDead = False
            
