import pygame
import random

class Boss :

    def __init__(self, screen):
        self.screen= screen
        self.boss_img = [ pygame.image.load("resource/boss_run/play_mombear_run_0.png"),
                          pygame.image.load("resource/boss_run/play_mombear_run_1.png"),
                          pygame.image.load("resource/boss_run/play_mombear_run_2.png"),
                          pygame.image.load("resource/boss_run/play_mombear_run_3.png"),
                          pygame.image.load("resource/boss_run/play_mombear_run_4.png"),
                          pygame.image.load("resource/boss_run/play_mombear_run_5.png"),
                          pygame.image.load("resource/boss_run/play_mombear_run_6.png") ]
        self.bsx = 800
        self.bsy = 400
        self.std_count = 0
        
        self.hp_img = pygame.image.load("resource/hp.png") #초록색 = 풀피
        self.bar_img = pygame.image.load("resource/hp_bar.png") #빨간색 빨피 

        self.moveD = True
        self.moveU = False

        self.fhp = 80
        self.hp = 80
        self.isDead = False
        
    def draw(self):
        if not self.isDead:
            self.screen.blit(self.boss_img[self.std_count//60], (self.bsx, self.bsy))
            self.screen.blit(self.bar_img , (self.bsx + 30 , self.bsy), (0,0 ,self.fhp, 20) )   #hp는 보스의 머리위에 그린다.  
            self.screen.blit(self.hp_img , (self.bsx + 30 , self.bsy), (0,0 ,self.hp, 20) )   #hp는 보스의 머리위에 그린다.

    def update(self):

        if self.moveD and self.bsy <= 1000:
            self.bsy += 1

            if self.bsy > 1000:
                self.bsx = random.randrange(0, 1800)
                self.moveD = False
                self.moveU = True

        if self.moveU and self.bsy >= 0:
            self.bsy -= 1

            if self.bsy < 0:
                self.bsx = random.randrange(0, 1800)
                self.moveU = False
                self.moveD = True

    def animation(self) :
        self.std_count += 1

        if self.std_count >= 419:
            self.std_count =0 
        
        
